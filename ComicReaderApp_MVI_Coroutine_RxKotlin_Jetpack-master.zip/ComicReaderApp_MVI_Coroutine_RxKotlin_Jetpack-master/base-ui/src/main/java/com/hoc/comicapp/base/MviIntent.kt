package com.hoc.comicapp.base

/**
 * Immutable object which represent an view's intent.
 */
interface MviIntent
