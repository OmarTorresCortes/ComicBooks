# Security Policy

## Reporting a Vulnerability

Please email hoc081098@gmail.com to report vunerabilities.
